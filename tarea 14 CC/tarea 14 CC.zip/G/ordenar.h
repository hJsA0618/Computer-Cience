#ifndef ORDENAR_H
#define ORDENAR_H

void intercambiar(int *a, int *b);
void ordenarIterativo(int arr[], int n);
void imprimirArreglo(int arr[], int n);

#endif 
