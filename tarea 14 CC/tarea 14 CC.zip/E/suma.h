#ifndef SUMA_H
#define SUMA_H

int sumaRecursiva(int vector[], int n);

#endif
